The refactor process includes:


Creating a model for Fitness Tracking, Nutrition Plan, and Personal Trainer
Adding routes for each feature
Import default HTML pages for each feature and modified the 'dashboard' page
Added error-handling and login protection for each route.

Revised Code:

from flask import Flask, request, redirect, url_for, render_template, flash
from flask_login import LoginManager, UserMixin, login_user, logout_user, current_user, login_required
from flask_sqlalchemy import SQLAlchemy
from werkzeug.security import generate_password_hash, check_password_hash

app = Flask(__name__)
app.config['SECRET_KEY'] = 'secret_key'
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:////tmp/test.db'
db = SQLAlchemy(app)

login_manager = LoginManager()
login_manager.init_app(app)

class User(UserMixin, db.Model):
    id = db.Column(db.Integer, primary_key=True)
    username = db.Column(db.String(15), unique=True)
    email = db.Column(db.String(50), unique=True)
    password = db.Column(db.String(80))

class Fitness(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey('user.id'))
    data = db.Column(db.Text)

class Nutrition(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey('user.id'))
    data = db.Column(db.Text)

class Trainer(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey('user.id'))
    data = db.Column(db.Text)

@login_manager.user_loader
def load_user(user_id):
    return User.query.get(int(user_id))

@app.route('/register', methods=['GET', 'POST'])
def register():
    ## original code ##
    return render_template('register.html')

@app.route('/login', methods=['GET', 'POST'])
def login():
    ## original code ##
    return render_template('login.html')

@app.route('/logout')
@login_required
def logout():
    ## original code ##
    return redirect(url_for('index'))

@app.route('/fitness', methods=['GET', 'POST'])
@login_required
def fitness():
    return render_template('fitness.html')

@app.route('/nutrition', methods=['GET', 'POST'])
@login_required
def nutrition():
    return render_template('nutrition.html')

@app.route('/trainer', methods=['GET', 'POST'])
@login_required
def trainer():
    return render_template('trainer.html')

@app.route('/dashboard')
@login_required
def dashboard():
    return render_template('dashboard.html')

if __name__ == "__main__":
    db.create_all()
    app.run(debug=True)